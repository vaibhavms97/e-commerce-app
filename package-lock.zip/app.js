const express = require('express');
const MongoClient = require('mongodb').MongoClient;
const cors = require('cors');

const app = express()
const url = 'mongodb://localhost:27017'

app.use(cors())
app.use(express.json())

MongoClient.connect(url, { useUnifiedTopology: true ,useNewUrlParser: true }, (err,client) =>{
    if(err) throw err;
    console.log('mongo')
    db = client.db('mall');
})

app.get('/login',(req,res) => {
    db.collection('login').find().toArray((err,values) => {
        if(err) throw err;
        res.json(values);
    })
})

app.post('/postLoginDetails',(req,res) =>{
    db.collection('login').insertOne(req.body,(err,values) => {
        if(err) throw err;
        res.send({message:'User added successfully'})
    })
})

app.listen(4000, () => console.log('Your port is listening at 4000'))