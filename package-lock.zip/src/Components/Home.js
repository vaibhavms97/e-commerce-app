import React,{Component} from 'react';
import './Home.css';

export default class Home extends Component{
    render(){
        return(
            <div className='products'>
                <div >
                    <img className='productImage' src='https://fi.google.com/about/static/images/phones/pixel-5/sorta-sage.png' alt='tv'></img>
                </div>
                <div className='productName'>
                    <label>TV</label>
                </div>
                <div className='productPrize'>
                    <label className='review'>4.4</label>
                    <label className='price'>250</label>
                </div>
                <div className='productDesc'>
                    <p>Very good tv</p>
                </div>
            </div>
        )
    }
}