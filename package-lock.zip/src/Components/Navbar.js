import React, { Component } from 'react';
import './Navbar.css';
import mallIcon from '../Images/mall.svg';
import { AiOutlineSearch } from 'react-icons/ai'

export default class Navbar extends Component {
    navHome(){
        window.location = '/home'
    }

    navLogin(){
        window.location = '/login'
    }
    render() {
        return (
            <div className='navBar'>
                <div className='row'>
                    <span className='mallIconSpan' onClick={this.navHome}><img src={mallIcon} className='mallIcon' alt='mall' id='mall'></img></span>
                    <h3 className='navMall' onClick={this.navHome}>Mall</h3>
                    <span className='searchBarSpan'>
                        <AiOutlineSearch className='searchIcon'/>
                        <input type='text' placeholder='Seach products' className='searchBar'></input>
                    </span>
                    <h5 className='navHome' onClick={this.navHome}>Home</h5>
                    <h5 className='navProducts'>Products</h5>
                    <span className='navLoginSpan' onClick={this.navLogin}><button className='navLogin'>Login</button></span>
                </div>
                {/* <div className='row title'>
                    <h3>Mall</h3>
                </div>
                <div className='nav-list'>
                    <div className='row nav-items'>
                        <h5>Home</h5>
                    </div>
                    <div className='row nav-items'>
                        <h5>Products</h5>
                    </div>
                    <div className='row nav-items'>
                        <h5>Login</h5>
                    </div>
                </div> */}
            </div>
        )
    }
}
