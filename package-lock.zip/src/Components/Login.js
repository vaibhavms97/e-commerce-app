import React, { Component } from 'react';
import Axios from 'axios';
import './Login.css';
import { VscChromeClose } from 'react-icons/vsc'

export default class Login extends Component {
    constructor() {
        super();
        this.state = {
            username: '',
            password: '',
            logindetails: [],
            value: 'gopi'
        }
    }
    componentDidMount() {
        Axios.get('http://localhost:4000/login')
            .then(response => {
                this.setState({ logindetails: response.data });
            })
    }

    checkLoginDetails() {
        let givenUsername = document.getElementById('username').value;
        let givenPassword = document.getElementById('password').value;
        for (const value of this.state.logindetails) {
            console.log(value.username + '--->' + value.password)
            if (value.username === givenUsername && value.password === givenPassword) {
                window.location = '/home'
            }
        }
    }

    closeLoginPage(){
        window.location = '/home'
    }

    register() {
        window.location = '/register'
    }
    render() {
        return (
            <div className='loginPage'>
                <div className='loginContainer'>
                    <VscChromeClose className='closeIcon' onClick={this.closeLoginPage}  />
                    <div>
                        <div>
                            <h3 className='heading'>Login</h3>
                        </div>
                        <p className='error'>{this.state.error}</p>
                        <div>
                            <label className='label'>Username:</label>
                        </div>
                        <div className='inputdiv'>
                            <input className='input' type='text' placeholder='Enter username' id='username'></input>
                        </div>
                        <div>
                            <label className='label password'>Password:</label>
                        </div>
                        <div className='inputdiv'>
                            <input className='input ' type='password' placeholder='Enter password' id='password'></input>
                        </div>
                        <div className='row login'>
                            <button id='button' className='btn' onClick={this.checkLoginDetails.bind(this)}>Login</button>
                        </div>
                        <div className='row register'>
                            <button id='button' className='btn' onClick={this.register.bind(this)}>Register</button>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}